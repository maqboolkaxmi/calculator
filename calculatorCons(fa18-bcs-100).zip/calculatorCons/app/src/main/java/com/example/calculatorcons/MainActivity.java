package com.example.calculatorcons;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    EditText ed1,ed2,ed3;
    Button bt1;
    Spinner sp1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.edt1);
        ed2=findViewById(R.id.edt2);
        ed3=findViewById(R.id.edt3);
        bt1=findViewById(R.id.btn1);
        sp1=findViewById(R.id.spin);




        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String selectedItem = (String) sp1.getSelectedItem();
                if(selectedItem.trim().equals("add")){

                    int result = Integer.parseInt(ed1.getText().toString())  + Integer.parseInt(ed2.getText().toString());

                    ed3.setText(String.valueOf(result));

                } else if(selectedItem.trim().equals("subtract")){

                    int result = Integer.parseInt(ed1.getText().toString())  - Integer.parseInt(ed2.getText().toString());

                    ed3.setText(String.valueOf(result));

                } else if(selectedItem.trim().equals("multiply")){

                    int result =Integer.parseInt(ed1.getText().toString())  * Integer.parseInt(ed2.getText().toString());

                    ed3.setText(String.valueOf(result));

                }else if(selectedItem.trim().equals("divide")){

                    int result = Integer.parseInt(ed1.getText().toString())  / Integer.parseInt(ed2.getText().toString());

                    ed3.setText(String.valueOf(result));

                }
            }
        });


    }
}